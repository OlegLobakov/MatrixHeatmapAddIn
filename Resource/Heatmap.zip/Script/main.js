﻿window.__controlAddInError__NAV = window.__controlAddInError;
window.__controlAddInError = function (e) {
    console.log("Unhandled error has occurred: '" + e.message + "' - Stack: " + e.stack);
    window.__controlAddInError__NAV(e);
};

let container;
let navControl;
let navControlContainer;
let AddInReady = false;
let UpdateIsEnabled = false;
let error;


function InitializeAddin() {
    try {
        navControlContainer = $("#controlAddIn");

        let html = '<div class="days-hours-heatmap" style="width:100%; height:100%"> \
            <svg role="heatmap" class="heatmap"></svg> \
        </div>';

        // remove whitespace (space and tabs) before tags
        html = html.replace(/[\t ]+\</g, "<");
        // remove whitespace between tags
        html = html.replace(/\>[\t ]+\</g, "><");
        // remove whitespace after tags
        html = html.replace(/\>[\t ]+$/g, ">");

        navControlContainer.append(html);
        container = document.getElementById('controlAddIn');
        ClearData();
        AddInReady = true;
    } catch (err) {
        RaiseCALEvent('OnError', ["Javascript Error :" + err]);
    }
    RaiseCALEvent('ControlAddIsReady', []);
}



let margin = { top: 20, right: 20, bottom: 20, left: 25 },
    width = 960,
    height = 500 - margin.top - margin.bottom,
    formatNumber = d3.format(",d"),
    transitioning,
    x,
    y,
    treemap,
    svg,
    data;

window.addEventListener('resize', function (event) {
    if (UpdateIsEnabled) {
        width = container.offsetWidth - margin.left - margin.right;
        height = container.offsetHeight - - margin.bottom - margin.top;
    }
});

function Update() {
    try {

        //UI configuration
        var itemSize = 18,
            cellSize = itemSize - 1,
            width = container.offsetWidth,
            height = container.offsetHeight;

        //formats
        var hourFormat = d3.time.format('%H'),
            dayFormat = d3.time.format('%j'),
            timeFormat = d3.time.format('%Y-%m-%dT%X'),
            monthDayFormat = d3.time.format('%d.%m'),
            fulldatetimeformat = d3.time.format('%c');


        //data vars for rendering
        var dateExtent = null,
            dayOffset = 0,
            colorCalibration = colorbrewer.YlOrRd[9],
            dailyValueExtent = {};

        //axises and scales
        var axisWidth = 0,
            axisHeight = itemSize * 24,
            xAxisScale = d3.time.scale(),
            xAxis = d3.svg.axis()
                .orient('top')
                .ticks(d3.time.days, 3)
                .tickFormat(monthDayFormat),
            yAxisScale = d3.scale.linear()
                .range([0, axisHeight])
                .domain([0, 24]),
            yAxis = d3.svg.axis()
                .orient('left')
                .ticks(5)
                .tickFormat(d3.format('02d'))
                .scale(yAxisScale);

        initCalibration();

        var svg = d3.select('[role="heatmap"]');
        var heatmap = svg
            .attr('width', width)
            .attr('height', height)
            .append('g')
            .attr('width', width - margin.left - margin.right)
            .attr('height', height - margin.top - margin.bottom)
            .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');
        var rect = null;

        dailyValueExtent = [100000000, -1];

        data.forEach(function (valueObj) {
            //valueObj['date'] = timeFormat.parse(valueObj['timestamp']);
            
            var day = valueObj['day'] = monthDayFormat(valueObj['date']);

            //var dayData = dailyValueExtent[day] = (dailyValueExtent[day] || [100000000, -1]);
            //var pmValue = valueObj['value'];
            //dayData[0] = d3.min([dayData[0], pmValue]);
            //dayData[1] = d3.max([dayData[1], pmValue]);

            var pmValue = valueObj['value'];
            dailyValueExtent[0] = d3.min([dailyValueExtent[0], pmValue]);
            dailyValueExtent[1] = d3.max([dailyValueExtent[1], pmValue]);
        });

        //RaiseCALEvent('OnError', ["JS :" + dailyValueExtent]);

        //min and max dates
        dateExtent = d3.extent(data, function (d) {
            return d.date;
        });       

        axisWidth = itemSize * (dayFormat(dateExtent[1]) - dayFormat(dateExtent[0]) + 1);

        //render axises
        xAxis.scale(xAxisScale.range([0, axisWidth]).domain([dateExtent[0], dateExtent[1]]));
        svg.append('g')
            .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
            .attr('class', 'x axis')
            .call(xAxis)
            .append('text')
            .text('date')
            .attr('transform', 'translate(' + axisWidth + ',-10)');

        svg.append('g')
            .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')
            .attr('class', 'y axis')
            .call(yAxis)
            .append('text')
            .text('time')
            .attr('transform', 'translate(-10,' + axisHeight + ') rotate(-90)');

        //render heatmap rects
        dayOffset = dayFormat(dateExtent[0]);
        rect = heatmap.selectAll('rect')
            .data(data)
            .enter().append('rect')
            .attr('width', cellSize)
            .attr('height', cellSize)
            .attr('x', function (d) {
                return itemSize * (dayFormat(d.date) - dayOffset);
            })
            .attr('y', function (d) {
                return hourFormat(d.date) * itemSize;
            })
            .attr('fill', '#ffffff')
            .on('click', clickeslot);

        rect.filter(function (d) { return d.value > 0; })
            .append('title')
            .text(function (d) {
                return 'Date: ' + fulldatetimeformat(d.date) + ' Value: ' + d.value;
            });

        renderColor();

        d3.select(self.frameElement).style("height", "600px");

    } catch (err) {
        RaiseCALEvent('OnError', ["Javascript error :" + err]);
    }

    function clickeslot(d) {
        RaiseCALEvent('OnClicked', [d.saveday, d.savemonth, d.saveyear, d.savehour1]);
    }

    function initCalibration() {
        d3.select('[role="calibration"] [role="example"]').select('svg')
            .selectAll('rect')
            .data(colorCalibration)
            .enter()
            .append('rect')
            .attr('width', cellSize)
            .attr('height', cellSize)
            .attr('x', function (d, i) {
                return i * itemSize;
            })
            .attr('fill', function (d) {
                return d;
            });
    }

    function renderColor() {
        rect.filter(function (d) {
            return d.value >= 0;
        })
            .transition()
            .delay(function (d) {
                return (dayFormat(d.date) - dayOffset) * 15;
            })
            .duration(500)
            .attrTween('fill', function (d, i, a) {
                //choose color dynamicly   
                //old code
                //var colorIndex = d3.scale.quantize()
                //    .range([0, 1, 2, 3, 4, 5, 6, 7, 8])
                //    .domain(dailyValueExtent[d.day]);

                var colorIndex = d3.scale.quantize()
                    .range([0, 1, 2, 3, 4, 5, 6, 7, 8])
                    .domain(dailyValueExtent);

                return d3.interpolate(a, colorCalibration[colorIndex(d.value)]);
            });
    }
}

function ClearData() {
    data = [];
}

function Add(day1, month1, year1, hour1, value1, selected1) {
    var date1 = new Date(year1, month1 - 1, day1, hour1, 0, 0);
    var newvalue = {
        "date": date1,
        "value": value1,
        "saveday": day1,
        "savemonth": month1,
        "saveyear" : year1,
        "savehour1": hour1,
        "selected": selected1
    };
    data.push(newvalue);
}

let currentnode;
let stack = [];


function RaiseCALEvent(eventName, args) {
    /// <summary>Raises an event trigger in C/AL` code.</summary>
    /// <param name="eventName">Name of the C/AL event trigger. The event must belong to the control and be declared in the IAdvancedExtensibilityControl interface.</param>
    /// <param name="args">Any event trigger parameters to pass to C/AL. This parameter is always of the array type, so you must enclose it in [].</param>
    Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(eventName, args);
}

